<?php
declare(strict_types=1);

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419); exit('Token formulir tidak valid. Muat ulang halaman dan coba lagi.');
    }
}
function flash(string $message, string $type = 'success'): void { $_SESSION['flash'] = [$message, $type]; }
function require_login(): void { if (empty($_SESSION['user'])) redirect('login.php'); }
function is_kepala(): bool { return ($_SESSION['user']['jabatan'] ?? '') === 'Kepala Arsiparis'; }
function password_matches(string $input, string $stored): bool
{
    // Kompatibilitas untuk akun lama yang dibuat saat prototype masih menyimpan hash.
    $info = password_get_info($stored);
    if (!empty($info['algo'])) return password_verify($input, $stored);
    return hash_equals($stored, $input);
}
function require_kepala(): void
{
    require_login();
    if (!is_kepala()) { http_response_code(403); exit('Akses ditolak. Hanya Kepala Arsiparis yang dapat mengelola SOP.'); }
}
function upload_file(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('File wajib dipilih atau proses upload gagal.');
    if (($file['size'] ?? 0) > 10 * 1024 * 1024) throw new RuntimeException('Ukuran file maksimal 10 MB.');
    $allowed = ['pdf','doc','docx','xls','xlsx','jpg','jpeg','png'];
    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) throw new RuntimeException('Format file tidak diizinkan. Gunakan PDF, Office, JPG, atau PNG.');
    $dir = dirname(__DIR__) . '/uploads';
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Folder upload tidak dapat dibuat.');
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) throw new RuntimeException('File gagal disimpan.');
    return 'uploads/' . $name;
}
function delete_physical_file(?string $path): void
{
    if (!$path) return;
    $base = realpath(dirname(__DIR__) . '/uploads');
    $target = realpath(dirname(__DIR__) . '/' . $path);
    if ($base && $target && str_starts_with($target, $base . DIRECTORY_SEPARATOR) && is_file($target)) unlink($target);
}

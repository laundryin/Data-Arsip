<?php
$title = $title ?? 'Sistem Pengarsipan';
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$pendingDestructionCount = 0;
if (!empty($_SESSION['user'])) {
    $pendingDestructionCount = (int)db()->query('SELECT COUNT(*) FROM dokumen WHERE tanggal_upload<=DATE_SUB(CURDATE(),INTERVAL 5 YEAR)')->fetchColumn();
}
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?=e($title)?> | ArsipKu</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/style.css" rel="stylesheet"><link href="assets/modern.css" rel="stylesheet"></head><body>
<?php if (!empty($_SESSION['user'])): ?>
<div class="app-shell">
<aside class="sidebar"><a class="brand" href="index.php"><span class="brand-mark">A</span><span>ARSIP<span class="brand-light">KU</span><small>SISTEM PENGARSIPAN</small></span></a><div class="side-caption">MENU BAR</div><nav class="side-nav">
<a class="side-link <?=$currentPage === 'index.php' ? 'active' : ''?>" href="index.php"><span class="side-icon">▦</span>Dashboard</a>
<a class="side-link <?=$currentPage === 'sop.php' ? 'active' : ''?>" href="sop.php"><span class="side-icon">☷</span>SOP Daur Hidup</a>
<a class="side-link <?=($currentPage === 'arsip.php' && !isset($_GET['lama'])) || $currentPage === 'folders.php' ? 'active' : ''?>" href="arsip.php"><span class="side-icon">▤</span>Data Arsip</a>
<a class="side-link <?=$currentPage === 'usul_musnah.php' ? 'active' : ''?>" href="usul_musnah.php"><span class="side-icon">♨</span>Usul Musnah<?php if ($pendingDestructionCount > 0): ?><span class="side-count"><?=$pendingDestructionCount?></span><?php endif; ?></a>
<div class="side-caption secondary-caption">LAINNYA</div>
<a class="side-link <?=$currentPage === 'laporan.php' ? 'active' : ''?>" href="laporan.php"><span class="side-icon">▥</span>Laporan</a>
<?php if (is_kepala()): ?><a class="side-link <?=$currentPage === 'pengguna.php' ? 'active' : ''?>" href="pengguna.php"><span class="side-icon">♙</span>Manajemen Pengguna</a><?php endif; ?>
</nav><div class="sidebar-user"><div class="user-avatar"><?=e(mb_substr($_SESSION['user']['nama_user'],0,1))?></div><div class="user-detail"><a href="akun.php"><strong><?=e($_SESSION['user']['username'])?></strong><small><?=e($_SESSION['user']['jabatan'])?> · Akun saya</small></a></div><a class="logout-link" href="logout.php" title="Keluar">Keluar</a></div></aside>
<div class="app-main"><header class="topbar"><button class="sidebar-toggle" type="button" aria-label="Buka menu" onclick="document.body.classList.toggle('sidebar-open')">☰</button><div><span class="topbar-eyebrow">SISTEM INFORMASI</span><span class="topbar-title"><?=e($title)?></span></div><div class="topbar-date"><?=e(date('d M Y'))?></div></header><main class="page-content">
<?php if (!empty($_SESSION['flash'])): [$message,$type] = $_SESSION['flash']; unset($_SESSION['flash']); ?><div class="alert alert-<?=e($type)?> alert-dismissible fade show"><?=e($message)?><button class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php else: ?>
<main class="container py-4 auth-layout">
<?php if (!empty($_SESSION['flash'])): [$message,$type] = $_SESSION['flash']; unset($_SESSION['flash']); ?><div class="alert alert-<?=e($type)?> alert-dismissible fade show"><?=e($message)?><button class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php endif; ?>
